# retrieval-augmented-generation-langchain
Example RAG project built using Langchain and Cloudflare's AI stack

[Check out the video showing this build on YouTube!](https://youtu.be/ygZO21A8WaA)
